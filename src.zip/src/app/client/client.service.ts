import { Injectable } from '@angular/core';
import { HttpClient,Response,RequestOptions,Headers } from '@angular/common/http';
import { IEmployee } from './employee';
import { Observable } from 'rxjs/Observable';

import { Client } from './client';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  constructor(private http: HttpClient) { }
  
  getAllClient(): Observable<Client[]>{
	return this.http.get("http://127.0.0.1:8989/ProjectDemo/retrieveAll")
	.map((response: Response)=>response.json()).catch(this.handleError);
  }
  
  private handleError(error: Response){
	return Observable.throw(error);
  }
}
