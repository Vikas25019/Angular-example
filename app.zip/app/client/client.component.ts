import { Component, OnInit } from '@angular/core';
import {Client} from './client';
import { ClientService } from './client.service';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})

export class ClientComponent implements OnInit {

  clients: Client[];
  client = new Client();
  constructor(private _clientService: ClientService) { }
	
	getClient():void{
	
		this._clientService.getAllClient()
		.subscribe((clientData) => {
			this.clients = clientData,
			console.log(clientData)
			},(error) =>{
			console.log(error);
		});
	}
  ngOnInit(): void {
  this.getClient();
  }

	addClient():void{
		this._clientService.addClient(this.client)
		.subscribe((response) => {
			console.log(response);
		},
		(error)=>{
			console.log(error);
		}
		
		)
	}
}
