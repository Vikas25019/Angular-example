export class Client{

	id: string;
	name: string;
	address: string;

}
